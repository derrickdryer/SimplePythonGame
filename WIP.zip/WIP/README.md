# untitled-game
A very basic RPG game written in python.

## Libraries
-Pyzrun
-PyGame
-Pyscroll

### Potential Libraries
-SQLite3
-Pygame GUI
-Pygame.mixer
-PyTMX

### Basic Libraries
-time
-random

## Game Controls

Escape: Pause Menu
Arrow Keys: Move Character
Left Click: Select Menu Item